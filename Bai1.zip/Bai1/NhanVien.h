#ifndef NHANVIEN_H
#define NHANVIEN_H

#include <bsiits/stdc++.h>

class NhanVien {
protected:
    std::string maNV;  
    std::string tenNV;  
    double luongCB;     
public:
    // H�m t?o
    NhanVien(const std::string &ma, const std::string &ten, double luong);

    virtual void Nhap() = 0; /
    virtual void Xuat() const = 0;
    virtual double TienThuong() const = 0; /
    virtual ~NhanVien() {} // Destructor 
};

class QuanLy : public NhanVien {
private:
    double tyLeThuong; 

public:
    
    QuanLy(const std::string &ma, const std::string &ten, double luong, double tyLe);

  
    void Nhap() override;


    void Xuat() const override;

    
    double TienThuong() const override;
};

class KySu : public NhanVien {
private:
    int soGioLamThem; 

public:
   
    KySu(const std::string &ma, const std::string &ten, double luong, int gioLamThem);

    
    void Nhap() override;

    
    void Xuat() const override;

   
    double TienThuong() const override;
};

#endif // NHANVIEN_H

