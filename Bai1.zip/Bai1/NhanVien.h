#ifndef NHANVIEN_H
#define NHANVIEN_H

#include <string>
#include <iostream>
using namespace std;

// Lop co so NhanVien
class NhanVien {
protected:
    string maNV;
    string ten;
    int luongCoBan;

public:
    NhanVien(const string& maNV = "", const string& ten = "", int luongCoBan = 0);
    virtual int TienThuong() const = 0; 
    virtual void Xuat() const;
    virtual ~NhanVien() = default; // Destructor
};

// Lop dan xuat QuanLy
class QuanLy : public NhanVien {
private:
    float tyLeThuong;

public:
    QuanLy(const string& maNV = "", const string& ten = "", int luongCoBan = 0, float tyLeThuong = 0);
    int TienThuong() const override;
    void Xuat() const override;
};

// Lop dan xuat KySu
class KySu : public NhanVien {
private:
    int soGioLamThem;

public:
    KySu(const string& maNV = "", const string& ten = "", int luongCoBan = 0, int soGioLamThem = 0);
    int TienThuong() const override;
    void Xuat() const override;
};

#endif

