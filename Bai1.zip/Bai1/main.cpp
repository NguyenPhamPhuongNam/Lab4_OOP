#include "NhanVien.h"

int main() {
    // Nhap th�ng tin cho Quan Ly
    string maQL, tenQL;
    int luongCoBanQL;
    float tyLeThuong;

    cout << "Nhap thong tin Quan Ly:\n";
    cout << "Ma NV: "; cin >> maQL;
    cout << "Ten: "; cin.ignore(); getline(cin, tenQL);
    cout << "Luong co ban: "; cin >> luongCoBanQL;
    cout << "Ty le thuong: "; cin >> tyLeThuong;

    QuanLy quanLy(maQL, tenQL, luongCoBanQL, tyLeThuong);

    // Nhap th�ng tin cho Ky Su
    string maKS, tenKS;
    int luongCoBanKS, soGioLamThem;

    cout << "\nNhap thong tin Ky Su:\n";
    cout << "Ma NV: "; cin >> maKS;
    cout << "Ten: "; cin.ignore(); getline(cin, tenKS);
    cout << "Luong co ban: "; cin >> luongCoBanKS;
    cout << "So gio lam them: "; cin >> soGioLamThem;

    KySu kySu(maKS, tenKS, luongCoBanKS, soGioLamThem);

    // Xuat th�ng tin
    cout << "\nThong tin Quan Ly:\n";
    quanLy.Xuat();

    cout << "\nThong tin Ky Su:\n";
    kySu.Xuat();

    return 0;
}

