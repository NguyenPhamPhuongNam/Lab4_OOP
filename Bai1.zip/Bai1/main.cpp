#include "NhanVien.h"
#include <bits/stdc++.h>

int main() {

    NhanVien* nhanVien1;
    NhanVien* nhanVien2;


    nhanVien1 = new QuanLy("QL001", "Nguyen Van A", 15000, 0.1); 
    nhanVien1->Nhap();
    nhanVien1->Xuat();


    nhanVien2 = new KySu("KS001", "Tran Thi B", 12000, 10); 
    nhanVien2->Nhap();
    nhanVien2->Xuat();


    delete nhanVien1;
    delete nhanVien2;

    return 0;
}

