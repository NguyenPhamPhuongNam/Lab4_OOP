#include "NhanVien.h"

// Constructor cua NhanVien
NhanVien::NhanVien(const string& maNV, const string& ten, int luongCoBan)
    : maNV(maNV), ten(ten), luongCoBan(luongCoBan) {}

void NhanVien::Xuat() const {
    cout << "Ma NV: " << maNV << ", Ten: " << ten
         << ", Luong co ban: " << luongCoBan << '\n';
}

// Constructor cua QuanLy
QuanLy::QuanLy(const string& maNV, const string& ten, int luongCoBan, float tyLeThuong)
    : NhanVien(maNV, ten, luongCoBan), tyLeThuong(tyLeThuong) {}

int QuanLy::TienThuong() const {
    return static_cast<int>(luongCoBan * tyLeThuong);
}

void QuanLy::Xuat() const {
    NhanVien::Xuat();
    cout << "Ty le thuong: " << tyLeThuong << ", Tien thuong: " << TienThuong() << '\n';
}

// Constructor cua KySu
KySu::KySu(const string& maNV, const string& ten, int luongCoBan, int soGioLamThem)
    : NhanVien(maNV, ten, luongCoBan), soGioLamThem(soGioLamThem) {}

int KySu::TienThuong() const {
    return soGioLamThem * 100000;
}

void KySu::Xuat() const {
    NhanVien::Xuat();
    cout << "So gio lam them: " << soGioLamThem << ", Tien thuong: " << TienThuong() << '\n';
}


