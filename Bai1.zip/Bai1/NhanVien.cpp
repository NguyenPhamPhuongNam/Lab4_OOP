#include "NhanVien.h"
#include <bits/stdc++.h>

NhanVien::NhanVien(const std::string &ma, const std::string &ten, double luong)
    : maNV(ma), tenNV(ten), luongCB(luong) {}

QuanLy::QuanLy(const std::string &ma, const std::string &ten, double luong, double tyLe)
    : NhanVien(ma, ten, luong), tyLeThuong(tyLe) {}

void QuanLy::Nhap() {
    std::cout << "Nhap ma nhan vien: ";
    std::cin >> maNV;
    std::cout << "Nhap ten nhan vien: ";
    std::cin.ignore();
    std::getline(std::cin, tenNV);
    std::cout << "Nhap luong co ban: ";
    std::cin >> luongCB;
    std::cout << "Nhap ty le thuong: ";
    std::cin >> tyLeThuong;
}

void QuanLy::Xuat() const {
    std::cout << "Ma nhan vien: " << maNV << "\n";
    std::cout << "Ten nhan vien: " << tenNV << "\n";
    std::cout << "Luong co ban: " << luongCB << "\n";
    std::cout << "Ty le thuong: " << tyLeThuong << "\n";
    std::cout << "Tien thuong: " << TienThuong() << "\n";
}

double QuanLy::TienThuong() const {
    return luongCB * tyLeThuong;
}

KySu::KySu(const std::string &ma, const std::string &ten, double luong, int gioLamThem)
    : NhanVien(ma, ten, luong), soGioLamThem(gioLamThem) {}

void KySu::Nhap() {
    std::cout << "Nhap ma nhan vien: ";
    std::cin >> maNV;
    std::cout << "Nhap ten nhan vien: ";
    std::cin.ignore();
    std::getline(std::cin, tenNV);
    std::cout << "Nhap luong co ban: ";
    std::cin >> luongCB;
    std::cout << "Nhap so gio lam them: ";
    std::cin >> soGioLamThem;
}

void KySu::Xuat() const {
    std::cout << "Ma nhan vien: " << maNV << "\n";
    std::cout << "Ten nhan vien: " << tenNV << "\n";
    std::cout << "Luong co ban: " << luongCB << "\n";
    std::cout << "So gio lam them: " << soGioLamThem << "\n";
    std::cout << "Tien thuong: " << TienThuong() << "\n";
}

double KySu::TienThuong() const {
    return soGioLamThem * 100000; // M?i gi? l�m th�m du?c tr? 100,000 VND
}

