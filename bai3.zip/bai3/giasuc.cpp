#include "giasuc.h"

using namespace std;

GiaSuc::GiaSuc(int soLuong) : soLuong(soLuong) {}

int GiaSuc::getSoLuong() const {
    return soLuong;
}


Bo::Bo(int soLuong) : GiaSuc(soLuong) {}

int Bo::SinhCon() {
    int tongCon = 0;
    for (int i = 0; i < soLuong; ++i)
        tongCon += rand() % 5 + 1;
    soLuong += tongCon;
    return tongCon;
}

int Bo::ChoSua() {
    int tongSua = 0;
    for (int i = 0; i < soLuong; ++i)
        tongSua += rand() % 21; 
    return tongSua;
}

void Bo::Keu() {
    cout << "Bo keu: Moo" << '\n';
}


Cuu::Cuu(int soLuong) : GiaSuc(soLuong) {}

int Cuu::SinhCon() {
    int tongCon = 0;
    for (int i = 0; i < soLuong; ++i)
        tongCon += rand() % 3 + 1; 
    soLuong += tongCon;
    return tongCon;
}

int Cuu::ChoSua() {
    int tongSua = 0;
    for (int i = 0; i < soLuong; ++i)
        tongSua += rand() % 6; 
    return tongSua;
}

void Cuu::Keu() {
    cout << "Cuu k�u: Baa" << '\n';
}


De::De(int soLuong) : GiaSuc(soLuong) {}

int De::SinhCon() {
    int tongCon = 0;
    for (int i = 0; i < soLuong; ++i)
        tongCon += rand() % 4 + 1; 
    soLuong += tongCon;
    return tongCon;
}

int De::ChoSua() {
    int tongSua = 0;
    for (int i = 0; i < soLuong; ++i)
        tongSua += rand() % 11; 
    return tongSua;
}

void De::Keu() {
    cout << "De k�u: Maa" << '\n';
}

