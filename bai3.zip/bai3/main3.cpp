#include "giasuc.h"

using namespace std;

int main() {
    srand(time(0)); 


    Bo bo(10);
    Cuu cuu(8);
    De de(12);

    cout << "Ti?ng k�u khi d�i:\n";
    bo.Keu();
    cuu.Keu();
    de.Keu();

    // Sinh con
    int tongConBo = bo.SinhCon();
    int tongConCuu = cuu.SinhCon();
    int tongConDe = de.SinhCon();

    // Cho sua
    int tongSuaBo = bo.ChoSua();
    int tongSuaCuu = cuu.ChoSua();
    int tongSuaDe = de.ChoSua();

    // Thong ke
    cout << "\nThong ke sau mot lua sinh va luot cho sua:\n";
    cout << "Bo - Tong so luong: " << bo.getSoLuong() << ", Tong sua: " << tongSuaBo << " lit, Tong con: " << tongConBo << '\n';
    cout << "Cuu - Tong so luong: " << cuu.getSoLuong() << ", Tong sua: " << tongSuaCuu << " lit, Tong con: " << tongConCuu << '\n';
    cout << "De - Tong so luong: "<< de.getSoLuong() << ", Tong sua: " << tongSuaDe << " lit, Tong con: " << tongConDe << '\n';

    return 0;
}

