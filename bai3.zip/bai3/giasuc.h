#ifndef GIASUC_H
#define GIASUC_H

#include <bits/stdc++.h>
#include <cstdlib> // rand()
#include <ctime>   // time()

class GiaSuc {
protected:
    int soLuong;
public:
    GiaSuc(int soLuong);
    virtual ~GiaSuc() {}
    virtual int SinhCon() = 0;
    virtual int ChoSua() = 0;
    virtual void Keu() = 0;
    int getSoLuong() const;
};

class Bo : public GiaSuc {
public:
    Bo(int soLuong);
    int SinhCon() override;
    int ChoSua() override;
    void Keu() override;
};

class Cuu : public GiaSuc {
public:
    Cuu(int soLuong);
    int SinhCon() override;
    int ChoSua() override;
    void Keu() override;
};

class De : public GiaSuc {
public:
    De(int soLuong);
    int SinhCon() override;
    int ChoSua() override;
    void Keu() override;
};

#endif

