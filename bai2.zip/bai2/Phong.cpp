#include "Phong.h"

// Dinh nghia ham khoi tao cua lop Phong
Phong::Phong(int soDem) : soDem(soDem) {}
Phong::~Phong() {}

// Dinh nghia ham cua lop Deluxe
Deluxe::Deluxe(int soDem, int phiDichVu, int phiPhucVu)
    : Phong(soDem), phiDichVu(phiDichVu), phiPhucVu(phiPhucVu) {}

int Deluxe::DoanhThu() const {
    return soDem * 750000 + phiDichVu + phiPhucVu;
}

// Dinh nghia ham cua lop Premium
Premium::Premium(int soDem, int phiDichVu)
    : Phong(soDem), phiDichVu(phiDichVu) {}

int Premium::DoanhThu() const {
    return soDem * 500000 + phiDichVu;
}

// Dinh nghia ham cua lop Business
Business::Business(int soDem) : Phong(soDem) {}

int Business::DoanhThu() const {
    return soDem * 300000;
}

