#include "Phong.h"
#include <bits/stdc++.h>

int main() {

    Deluxe a(5, 100000, 50000);    // 5 dem, phi dich vu 100000, phi dich vu 50000
    Deluxe b(3, 200000, 100000);  // 3 dem, phi dich vu 200000, phi dich vu 100000
    Premium c(4, 50000);          // 4 dem, phi dich vu 50000
    Premium d(6, 150000);         // 6 dem, phi dich vu 150000
    Business e(7);                // 7 dem

    
    vector<Phong*> danhSachPhong = {&a, &b, &c, &d, &e};
    int doanhThuDeluxe = 0, doanhThuPremium = 0, doanhThuBusiness = 0;

    for (Phong* phong : danhSachPhong) {
        if (dynamic_cast<Deluxe*>(phong)) {
            doanhThuDeluxe += phong->DoanhThu();
        } else if (dynamic_cast<Premium*>(phong)) {
            doanhThuPremium += phong->DoanhThu();
        } else if (dynamic_cast<Business*>(phong)) {
            doanhThuBusiness += phong->DoanhThu();
        }
    }

   
    cout << "Doanh thu Deluxe: " << doanhThuDeluxe << '\n';
    cout << "Doanh thu Premium: " << doanhThuPremium << '\n';
    cout << "Doanh thu Business: " << doanhThuBusiness << '\n';

    int maxDoanhThu = max({doanhThuDeluxe, doanhThuPremium, doanhThuBusiness});
    if (maxDoanhThu == doanhThuDeluxe) {
        cout << "Loai phong co doanh thu cao nhat: Deluxe\n";
    } else if (maxDoanhThu == doanhThuPremium) {
        cout << "Loai phong co doanh thu cao nhat: Premium\n";
    } else {
        cout << "Loai phong co doanh thu cao nhat: Business\n";
    }

    return 0;
}

