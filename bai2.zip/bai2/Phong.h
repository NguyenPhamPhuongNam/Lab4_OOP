#ifndef PHONG_H
#define PHONG_H

#include <bits/stdc++.h>
using namespace std;

// Lop co so Phong
class Phong {
protected:
    int soDem; // So dem luu tru

public:
    Phong(int soDem);
    virtual ~Phong();

    virtual int DoanhThu() const = 0; // Ham ao tinh doanh thu
};

// Lop Deluxe ke thua tu Phong
class Deluxe : public Phong {
private:
    int phiDichVu;
    int phiPhucVu;

public:
    Deluxe(int soDem, int phiDichVu, int phiPhucVu);
    int DoanhThu() const override;
};

// Lop Premium ke thua tu Phong
class Premium : public Phong {
private:
    int phiDichVu;

public:
    Premium(int soDem, int phiDichVu);
    int DoanhThu() const override;
};

// Lop Business ke thua tu Phong
class Business : public Phong {
public:
    Business(int soDem);
    int DoanhThu() const override;
};

#endif

